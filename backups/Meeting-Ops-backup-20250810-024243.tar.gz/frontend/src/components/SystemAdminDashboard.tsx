import React from 'react';

export const SystemAdminDashboard: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      <h1 className="text-3xl font-bold mb-2">System Admin Dashboard</h1>
      <p className="text-gray-400">Manage system-level configurations.</p>
    </div>
  );
};