import React from 'react';

export const AdminDashboard: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
      <p className="text-gray-400">Manage recording sessions, users, and system settings.</p>
    </div>
  );
};