import React from 'react';
import { UltimateDashboard } from './UltimateDashboard';

// AdminDashboard uses the UltimateDashboard with admin role context
export const AdminDashboard: React.FC = () => {
  return <UltimateDashboard />;
};