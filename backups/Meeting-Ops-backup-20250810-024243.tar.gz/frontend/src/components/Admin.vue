<template>
  <div>
    <h1>Admin Dashboard</h1>
    <div class="app-management">App Settings</div>
    <div class="hardware-config">
      <h2>Hardware Config</h2>
      <section>Network Settings</section>
      <section>WiFi Config</section>
    </div>
  </div>
</template>

<div class="hardware-config">
  <h2>Hardware Config</h2>
  <section>Network/WiFi Settings</section>
</div>

<div class="hardware-config">
  <h2>Hardware Config</h2>
  <section>Network/WiFi Settings</section>
</div>

<div class="hardware-config">
  <h2>Hardware Config</h2>
  <section>Network/WiFi Settings</section>
</div>
