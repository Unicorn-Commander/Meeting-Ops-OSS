// Export all pages from a single index file
export { RecordingPage } from './RecordingPage';
export { MeetingManagement } from './MeetingManagement';
export { SummarizationTemplates } from './SummarizationTemplates';
export { TranscriptEditor } from './TranscriptEditor';