"""
Working Audio Service - Simple, reliable audio capture using ffmpeg
This replaces all the complex audio services with one that actually works
"""

import subprocess
import threading
import queue
import logging
import os
import time
import json
import signal
import redis
from typing import Optional, Callable
from datetime import datetime

logger = logging.getLogger(__name__)

class WorkingAudioService:
    """
    Simple audio service that actually works
    - Uses ffmpeg with PulseAudio (works around ALSA conflicts)
    - Provides recording functionality
    - Feeds audio to transcription
    - Monitors audio levels
    """
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if hasattr(self, 'initialized'):
            return
        
        self.initialized = True
        self.recording_process = None
        self.current_session_id = None
        self.is_recording = False
        
        # Redis for audio levels
        self.redis_client = redis.from_url(os.getenv("REDIS_URL", "redis://localhost:6379"))
        
        # For live transcription
        self.transcription_callback = None
        self.audio_buffer = bytearray()
        
        logger.info("✅ Working Audio Service initialized")
        
    def start_recording(self, session_id: str, output_dir: Optional[str] = None) -> tuple[bool, str]:
        """
        Start recording audio using ffmpeg
        Returns: (success, filepath_or_error)
        """
        if self.is_recording:
            return False, "Already recording another session"
        
        # Default output directory
        if output_dir is None:
            output_dir = "/home/ucadmin/Meeting-Ops/backend/recordings"
        
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = os.path.join(output_dir, f"recording_{session_id}_{timestamp}.wav")
        
        # Build arecord command - use USB mic directly via ALSA
        cmd = [
            'arecord',
            '-D', 'hw:0,0',     # USB mic device directly
            '-f', 'S16_LE',     # 16-bit signed little-endian
            '-c', '1',          # Mono
            '-r', '44100',      # 44.1kHz sample rate
            '-d', '30',         # Max duration 30 seconds (safety limit)
            output_file
        ]
        
        try:
            # Start ffmpeg process
            self.recording_process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            self.is_recording = True
            self.current_session_id = session_id
            self.current_output_file = output_file
            
            # Start monitoring thread
            monitor_thread = threading.Thread(
                target=self._monitor_recording,
                args=(session_id,),
                daemon=True
            )
            monitor_thread.start()
            
            logger.info(f"🎤 Started recording session {session_id}")
            logger.info(f"   Output: {output_file}")
            
            # Update Redis status
            self.redis_client.hset(f"recording:{session_id}", mapping={
                "status": "recording",
                "started_at": datetime.now().isoformat(),
                "output_file": output_file
            })
            
            return True, output_file
            
        except Exception as e:
            logger.error(f"Failed to start recording: {e}")
            self.is_recording = False
            return False, str(e)
    
    def stop_recording(self, session_id: str) -> tuple[bool, str]:
        """
        Stop recording
        Returns: (success, filepath_or_error)
        """
        if not self.is_recording or self.current_session_id != session_id:
            return False, "Not recording this session"
        
        try:
            # For arecord, we need to send SIGINT to stop gracefully
            if self.recording_process:
                # Send SIGINT to arecord (like Ctrl+C)
                self.recording_process.send_signal(signal.SIGINT)
                
                # Wait for graceful shutdown
                try:
                    self.recording_process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    # If graceful shutdown fails, terminate
                    self.recording_process.terminate()
                    try:
                        self.recording_process.wait(timeout=2)
                    except subprocess.TimeoutExpired:
                        # Force kill if needed
                        self.recording_process.kill()
                        self.recording_process.wait(timeout=1)
            
            self.is_recording = False
            output_file = self.current_output_file
            
            # Check if file was created
            if os.path.exists(output_file):
                size = os.path.getsize(output_file)
                duration = size / (44100 * 2)  # Approximate duration in seconds
                
                logger.info(f"⏹️ Stopped recording session {session_id}")
                logger.info(f"   File: {output_file}")
                logger.info(f"   Size: {size:,} bytes")
                logger.info(f"   Duration: ~{duration:.1f} seconds")
                
                # Update Redis
                self.redis_client.hset(f"recording:{session_id}", mapping={
                    "status": "completed",
                    "stopped_at": datetime.now().isoformat(),
                    "file_size": size,
                    "duration": duration
                })
                
                return True, output_file
            else:
                return False, "Recording file not found"
                
        except Exception as e:
            logger.error(f"Failed to stop recording: {e}")
            return False, str(e)
        finally:
            self.current_session_id = None
            self.recording_process = None
    
    def _monitor_recording(self, session_id: str):
        """Monitor recording process and update status"""
        while self.is_recording and self.current_session_id == session_id:
            try:
                # Update audio levels in Redis
                # (In a real implementation, we'd parse ffmpeg stderr for levels)
                self.redis_client.publish('audio:levels', json.dumps({
                    'session_id': session_id,
                    'timestamp': datetime.now().isoformat(),
                    'level': 0.5,  # Placeholder
                    'status': 'recording'
                }))
                
                time.sleep(0.1)  # Update every 100ms
                
            except Exception as e:
                logger.error(f"Monitor error: {e}")
                break
    
    def get_recording_status(self, session_id: str) -> dict:
        """Get current recording status"""
        if self.is_recording and self.current_session_id == session_id:
            return {
                'recording': True,
                'session_id': session_id,
                'output_file': self.current_output_file
            }
        
        # Check Redis for historical status
        data = self.redis_client.hgetall(f"recording:{session_id}")
        if data:
            return {k.decode(): v.decode() for k, v in data.items()}
        
        return {'recording': False, 'session_id': session_id}
    
    def start_live_capture(self, callback: Optional[Callable] = None):
        """
        Start capturing audio for live transcription
        This runs continuously and feeds audio to a callback
        """
        if callback:
            self.transcription_callback = callback
        
        # Start a separate ffmpeg process for live capture
        cmd = [
            'ffmpeg',
            '-f', 'pulse',
            '-i', 'default',
            '-ac', '1',
            '-ar', '44100',
            '-f', 's16le',  # Raw PCM output
            '-'  # Output to stdout
        ]
        
        def capture_thread():
            try:
                process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
                
                while True:
                    # Read audio chunks (2 seconds at a time for transcription)
                    chunk_size = 44100 * 2 * 2  # 44.1kHz * 2 bytes * 2 seconds
                    audio_chunk = process.stdout.read(chunk_size)
                    
                    if not audio_chunk:
                        break
                    
                    # Send to callback if registered
                    if self.transcription_callback:
                        self.transcription_callback(audio_chunk)
                    
                    # Also publish to Redis for other consumers
                    self.redis_client.publish('audio:raw', audio_chunk)
                    
            except Exception as e:
                logger.error(f"Live capture error: {e}")
        
        thread = threading.Thread(target=capture_thread, daemon=True)
        thread.start()
        logger.info("🎙️ Started live audio capture for transcription")
    
    def cleanup(self):
        """Clean up resources"""
        if self.is_recording:
            self.stop_recording(self.current_session_id)
        self.redis_client.close()

# Global singleton instance
audio_service = WorkingAudioService()